library(dplyr)
library(tidyverse)
library(purrr)

world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
mcolor <- c("red", "yellow", "green", "navy", "blue", "orange", "black", "darkgreen", "green", "blue")
lcolor <- c("blue", "darkgreen", "red", "red", "orange", "orange", "grey", "green", "yellow", "yellow")

# par(mar=c(1,1,1,1))
par(mfrow = c(1,1))

team_spider <- function(n){
  load("team_stats.Rdata")
  max_stats <- c()
  min_stats <- c()
  team_stats <- team_stats %>% mutate(Team_Bowl_RAve = 1/Team_Bowl_Ave, Team_Bowl_REco = 1/Team_Bowl_Eco, Team_Bowl_RSR = 1/Team_Bowl_SR)
  
  for (i in 2:15){
    max_stats[i-1] <- max(team_stats[i])
    min_stats[i-1] <- min(team_stats[i])
  }
  team_stats[11,1] = "Max"
  team_stats[12,1] = "Min"
  
  for (i in 2:15){
    team_stats[11,i] = max_stats[i-1]
    team_stats[12,i] = min_stats[i-1]
  }
  
  rownames(team_stats) <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL", "Max", "Min")
  batball_stats <- team_stats[-c(1, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
  win_stats <- team_stats[-c(1,2,3,4,5,6,10,11,13,14,15)]
  colnames(win_stats)[4] <- "Win_perc"
  batball_stats <- batball_stats %>% relocate(Team_Bowl_REco, Team_Bowl_RAve, Team_Bat_Ave, Team_Bat_SR, Team_Bowl_RSR)
  
  library(fmsb)
  team_data <- batball_stats[c("Max", "Min", world_cup_teams[n]), ]
  
  title <- paste(world_cup_teams[n], "Data")
  
  radarchart(team_data, title = title, pcol = lcolor[n], pfcol = scales::alpha(mcolor[n], 0.5))
}

teams_spider <- function(m, n){
  load("team_stats.Rdata")
  max_stats <- c()
  min_stats <- c()
  team_stats <- team_stats %>% mutate(Team_Bowl_RAve = 1/Team_Bowl_Ave, Team_Bowl_REco = 1/Team_Bowl_Eco, Team_Bowl_RSR = 1/Team_Bowl_SR)
  
  for (i in 2:15){
    max_stats[i-1] <- max(team_stats[i])
    min_stats[i-1] <- min(team_stats[i])
  }
  team_stats[11,1] = "Max"
  team_stats[12,1] = "Min"
  
  for (i in 2:15){
    team_stats[11,i] = max_stats[i-1]
    team_stats[12,i] = min_stats[i-1]
  }
  
  rownames(team_stats) <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL", "Max", "Min")
  batball_stats <- team_stats[-c(1, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
  win_stats <- team_stats[-c(1,2,3,4,5,6,10,11,13,14,15)]
  colnames(win_stats)[4] <- "Win_perc"
  batball_stats <- batball_stats %>% relocate(Team_Bowl_REco, Team_Bowl_RAve, Team_Bat_Ave, Team_Bat_SR, Team_Bowl_RSR)
  
  library(fmsb)
  team_data <- batball_stats[c("Max", "Min", world_cup_teams[m], world_cup_teams[n]), ]
  
  title <- paste(world_cup_teams[m],"and", world_cup_teams[n], "Data Comparison")
  mcol <- c(mcolor[m], mcolor[n])
  lcol <- c(lcolor[m], lcolor[n])
  radarchart(team_data, title = title, pcol = lcol, pfcol = scales::alpha(mcol, 0.5))
}
teams_spider(2,4)
for (i in 1:10){
  team_spider(i)
}














team_stats <- read.csv("team_stats.csv")
max_stats <- c()
min_stats <- c()
team_stats <- team_stats %>% mutate(Team_Bowl_RAve = 1/Team_Bowl_Ave, Team_Bowl_REco = 1/Team_Bowl_Eco, Team_Bowl_RSR = 1/Team_Bowl_SR)

for (i in 2:15){
  max_stats[i-1] <- max(team_stats[i])
  min_stats[i-1] <- min(team_stats[i])
}
team_stats[11,1] = "Max"
team_stats[12,1] = "Min"

for (i in 2:15){
  team_stats[11,i] = max_stats[i-1]
  team_stats[12,i] = min_stats[i-1]
}

rownames(team_stats) <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL", "Max", "Min")
batball_stats <- team_stats[-c(1, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
win_stats <- team_stats[-c(1,2,3,4,5,6,10,11,13,14,15)]
colnames(win_stats)[4] <- "Win_perc"
batball_stats <- batball_stats %>% relocate(Team_Bowl_REco, Team_Bowl_RAve, Team_Bat_Ave, Team_Bat_SR, Team_Bowl_RSR)

library(fmsb)
team_data <- batball_stats[c("Max", "Min", world_cup_teams[2]), ]

title <- paste(world_cup_teams[2], "Data")

radarchart(team_data, title = title, pcol = lcolor[2], pfcol = scales::alpha(mcolor[2], 0.5))
