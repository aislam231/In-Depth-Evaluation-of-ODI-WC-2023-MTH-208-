library(ggplot2)
library(dplyr)
load("data_2.Rdata")


teams <- c("Afghanistan", "Australia", "Bangladesh", "England", "India",
           "Netherlands", "New Zealand", "Pakistan", "South Africa", "Sri Lanka")
matches <- numeric(10)
wins <- numeric(10)
for (i in 1:10){
  win1 <- dim(winloss %>% filter(Team.1 == teams[i]) %>% filter(Winner == teams[i]))[1]
  match1 <- dim(winloss %>% filter(Team.1 == teams[i]))[1]
  win2 <- dim(winloss %>% filter(Team.2 == teams[i]) %>% filter(Winner == teams[i]))[1]
  match2 <- dim(winloss %>% filter(Team.2 == teams[i]))[1]
  win <- win1 + win2
  match <- match1 + match2
  wins[i] <- win
  matches[i] <- match
}


team_data <- data_2 %>% filter(Team == "AFG")
team_data <- team_data %>% mutate(Runs_Ave = Bat_Runs * Bat_Ave) %>% mutate(Runs_SR = Bat_Runs * Bat_SR) %>% 
  mutate(Wkts_Ave = case_when(Bowl_Wkts < 5 ~ 0, Bowl_Wkts >= 5 ~ Bowl_Ave/Bowl_Wkts)) %>% 
  mutate(Overs_Eco = case_when(Bowl_Overs < 10 ~ 0, Bowl_Overs >= 10 ~ Bowl_Eco/Bowl_Overs)) %>% 
  mutate(Wkts_SR = case_when(Bowl_Wkts < 5 ~ 0, Bowl_Wkts >= 5 ~ Bowl_SR/Bowl_Wkts)) %>% 
  mutate(RWkts = case_when(Bowl_Wkts < 5 ~ 0, Bowl_Wkts >= 5 ~ 1/Bowl_Wkts)) %>% 
  mutate(ROvers = case_when(Bowl_Overs < 10 ~ 0, Bowl_Overs >= 10 ~ 1/Bowl_Overs))
bat <- team_data %>% filter(Type == "Batsman" | Type == "Allrounder")
bowl <- team_data %>% filter(Type == "Bowler" | Type == "Allrounder")
team_bat_ave <- sum(bat$Runs_Ave)/sum(bat$Bat_Runs)
team_bat_SR <- sum(bat$Runs_SR)/sum(bat$Bat_Runs)
team_bowl_ave <- sum(bowl$Wkts_Ave)/sum(bowl$RWkts)
team_bowl_eco <- sum(bowl$Overs_Eco)/sum(bowl$ROvers)
team_bowl_SR <- sum(bowl$Wkts_SR)/sum(bowl$RWkts)

table <- as.tibble(c(team_bat_ave, team_bat_SR, team_bowl_ave, team_bowl_eco, team_bowl_SR))
colnames(table) <- "AFG"

world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")


for (i in 2:10){
  team_data <- data_2 %>% filter(Team == world_cup_teams[i])
  team_data <- team_data %>% mutate(Runs_Ave = Bat_Runs * Bat_Ave) %>% mutate(Runs_SR = Bat_Runs * Bat_SR) %>% 
    mutate(Wkts_Ave = case_when(Bowl_Wkts < 5 ~ 0, Bowl_Wkts >= 5 ~ Bowl_Ave/Bowl_Wkts)) %>% 
    mutate(Overs_Eco = case_when(Bowl_Overs < 10 ~ 0, Bowl_Overs >= 10 ~ Bowl_Eco/Bowl_Overs)) %>% 
    mutate(Wkts_SR = case_when(Bowl_Wkts < 5 ~ 0, Bowl_Wkts >= 5 ~ Bowl_SR/Bowl_Wkts)) %>% 
    mutate(RWkts = case_when(Bowl_Wkts < 5 ~ 0, Bowl_Wkts >= 5 ~ 1/Bowl_Wkts)) %>% 
    mutate(ROvers = case_when(Bowl_Overs < 10 ~ 0, Bowl_Overs >= 10 ~ 1/Bowl_Overs))
  bat <- team_data %>% filter(Type == "Batsman" | Type == "Allrounder")
  bowl <- team_data %>% filter(Type == "Bowler" | Type == "Allrounder")
  team_bat_ave <- sum(bat$Runs_Ave)/sum(bat$Bat_Runs)
  team_bat_SR <- sum(bat$Runs_SR)/sum(bat$Bat_Runs)
  team_bowl_ave <- sum(bowl$Wkts_Ave)/sum(bowl$RWkts)
  team_bowl_eco <- sum(bowl$Overs_Eco)/sum(bowl$ROvers)
  team_bowl_SR <- sum(bowl$Wkts_SR)/sum(bowl$RWkts)
  
  team_stats = as.tibble(c(team_bat_ave, team_bat_SR, team_bowl_ave, team_bowl_eco, team_bowl_SR))
  colnames(team_stats) = world_cup_teams[i]
  
  table <- tibble(table, team_stats)
}
rownames(table) <- c("Team_Bat_Ave", "Team_Bat_SR", "Team_Bowl_Ave", "Team_Bowl_Eco", "Team_Bowl_SR")
table <- t(as.matrix(table))









