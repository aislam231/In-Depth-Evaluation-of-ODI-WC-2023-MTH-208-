library(dplyr)
library(rvest)
library(tidyverse)
library(purrr)

html <- read_html("https://currentaffairs.adda247.com/world-cup-2023-schedule/")
table <- html %>% html_table()
table <- table[[1]]
teams <- table[1]
results <- table[4]
results[33,] = "India"
schedule <- data.frame()
for (i in 1:45){
  if (strsplit(as.character(teams[i,]), " vs ")[[1]][1] == as.character(results[i,])){
    schedule[i, 1] = strsplit(as.character(teams[i,]), " vs ")[[1]][1]
    schedule[i, 2] = strsplit(as.character(teams[i,]), " vs ")[[1]][2]
  }
  else{
    schedule[i, 1] = strsplit(as.character(teams[i,]), " vs ")[[1]][2]
    schedule[i, 2] = strsplit(as.character(teams[i,]), " vs ")[[1]][1]
  }
}
schedule[7,2] <- "Bangladesh"
cap_world_cup_teams <- c("Afghanistan","Australia","Bangladesh","England","India",
                         "Netherlands","New Zealand", "Pakistan", "South Africa", "Sri Lanka")
world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")

for (i in 1:10){
  schedule[schedule==cap_world_cup_teams[i]] <- world_cup_teams[i]
}
colnames(schedule) <- c("Team1", "Team2")
