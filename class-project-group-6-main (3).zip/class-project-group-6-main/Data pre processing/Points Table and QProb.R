load("schedule.Rdata")
load("points_table.Rdata")
load("win_record.Rdata")

pts_mat_func <- function(mat){
  blank_table <- points_table
  blank_table[c(2,3,4,6)] <- rep(0,10)
  
  pts_mat <- blank_table
  if(mat == 0){
    blank_table <- blank_table %>% mutate_at(c(2,3,4,6), as.integer)
    return(blank_table)
  }
  for (i in 1:mat){
    team1 <- schedule[i, 1]
    team2 <- schedule[i, 2]
    
    index1 <- which(pts_mat$Team==team1)
    index2 <- which(pts_mat$Team==team2)
    
    pts_mat[index1, 2] <- pts_mat[index1, 2] + 1
    pts_mat[index2, 2] <- pts_mat[index2, 2] + 1
    pts_mat[index1, 6] <- pts_mat[index1, 6] + 2
    pts_mat[index1, 3] <- pts_mat[index1, 3] + 1
    pts_mat[index2, 4] <-pts_mat[index2, 4] + 1
    
    pts_mat <- pts_mat %>% arrange(desc(Pts), desc(NRR))
  }
  pts_mat <- pts_mat %>% mutate_at(c(2,3,4,6), as.integer)
  return(pts_mat)
}
pts_mat_func(25)


eq_prob <- function(mat){
  points_table <- read.csv("points_table.csv")
  blank_table <- points_table
  blank_table[c(2,3,4,6)] <- rep(0,10)
  
  pts_end <- pts_mat_func(mat)
  
  qteams <- function(){
    for (n in (mat+1):45){
      team1 <- schedule[n, 1]
      team2 <- schedule[n, 2]
      index1<-which(pts_end$Team==team1)
      index2<-which(pts_end$Team==team2)
      w <- rbinom(n=1,size=1,prob = 0.5)
      pts_end[index1, 2] <- pts_end[index1, 2] + 1
      pts_end[index2, 2] <- pts_end[index2, 2] + 1
      if(w == 1){
        pts_end[index1, 6] <- pts_end[index1, 6] + 2
        pts_end[index1, 3] <- pts_end[index1, 3] + 1
        pts_end[index2, 4] <-pts_end[index2, 4] + 1
      } else{
        pts_end[index2, 6] <- pts_end[index2, 6] + 2
        pts_end[index2, 3] <- pts_end[index2, 3] + 1
        pts_end[index1, 4] <-pts_end[index1, 4] + 1
      }
      pts_end <- pts_end %>% arrange(desc(Pts), desc(NRR))
    }
    teams <- pts_end$Team[1:4]
    return(teams)
  }
  
  world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
  qprob <- data.frame(world_cup_teams, rep(0, 10))
  colnames(qprob) <- c("Team", "Mat_won")
  
  for (i in 1:1e3){
    c <- qteams()
    for (j in 1:10){
      qprob[j,2] <- qprob[j,2] + as.numeric(qprob[j,1] %in% c)
    }
  }
  qprob <- qprob %>% mutate(Qualification_probability = `Mat_won`/10)
  qprob <- qprob[-2]
  qprob <- qprob %>% arrange(desc(Qualification_probability))
  return(qprob)
}
past_prob <- function(mat){
  blank_table <- points_table
  blank_table[c(2,3,4,6)] <- rep(0,10)
  
  pts_end <- pts_mat_func(mat)
  
  qteams <- function(){
    for (n in (mat+1):45){
      team1 <- schedule[n, 1]
      team2 <- schedule[n, 2]
      index1<-which(pts_end$Team==team1)
      index2<-which(pts_end$Team==team2)
      id1 <- which(win_record$Team==team1)
      id2 <- which(win_record$Team==team2) + 1
      w <- rbinom(n=1,size=1,prob = win_record[id1, id2])
      pts_end[index1, 2] <- pts_end[index1, 2] + 1
      pts_end[index2, 2] <- pts_end[index2, 2] + 1
      if(w == 1){
        pts_end[index1, 6] <- pts_end[index1, 6] + 2
        pts_end[index1, 3] <- pts_end[index1, 3] + 1
        pts_end[index2, 4] <-pts_end[index2, 4] + 1
      } else{
        pts_end[index2, 6] <- pts_end[index2, 6] + 2
        pts_end[index2, 3] <- pts_end[index2, 3] + 1
        pts_end[index1, 4] <-pts_end[index1, 4] + 1
      }
      pts_end <- pts_end %>% arrange(desc(Pts), desc(NRR))
    }
    teams <- pts_end$Team[1:4]
    return(teams)
  }
  
  world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
  qprob <- data.frame(world_cup_teams, rep(0, 10))
  colnames(qprob) <- c("Team", "Mat_won")
  
  for (i in 1:1e3){
    c <- qteams()
    for (j in 1:10){
      qprob[j,2] <- qprob[j,2] + as.numeric(qprob[j,1] %in% c)
    }
  }
  qprob <- qprob %>% mutate(Qualification_probability = `Mat_won`/10)
  qprob <- qprob[-2]
  qprob <- qprob %>% arrange(desc(Qualification_probability))
  return(qprob)
}


