# odi batting ranking 
library(rvest)
library(dplyr)
library(tidyverse)

html <- read_html("https://www.icc-cricket.com/rankings/mens/player-rankings/odi/batting")
table <- html%>%html_table()
odi_batting <- table[[1]]
odi_batting <- odi_batting%>%select("Pos","Player","Team","Rating","Career Best Rating")
odi_batting[1] <- 1:100
odi_batting <- odi_batting[-c(51:100),]

# how many players of each country
by_country <- odi_batting %>% group_by(Team)
no_of_players_batting <- by_country %>% summarise(Top.batters = n()) %>% arrange(desc(Top.batters))

# average ratings of players of a team
average_rating_batting <- by_country %>% 
  summarise(Avg.batting.rank = mean(Pos)) %>%
  arrange(Avg.batting.rank)

world_cup_teams <- c("AUS","ENG","IND","SA","BAN","PAK","AFG","NZ","SL","NED")
no_of_players_batting <- no_of_players_batting %>% filter(Team %in% world_cup_teams)
average_rating_batting <- average_rating_batting %>% filter(Team %in% world_cup_teams)
# result : SA has better avg_ranking and AUS, ENG and IND have more no of players in top 50 rankings
# in batting department SA and IND have an upper hand in ODI WORLD CUP



# odi bowling ranking 
html<-read_html("https://www.icc-cricket.com/rankings/mens/player-rankings/odi/bowling")
table<-html%>%html_table()
odi_bowling<-table[[1]]
odi_bowling<-odi_bowling%>%select("Pos","Player","Team","Rating","Career Best Rating")
odi_bowling[1] <- 1:100
odi_bowling <- odi_bowling[-c(51:100),]

# how many players of each country
by_country <- odi_bowling %>% group_by(Team)
no_of_players_bowling <- by_country %>% summarise(Top.bowlers = n()) %>% arrange(desc(Top.bowlers))

# average ratings of players of a team
average_rating_bowling<-by_country %>% 
  summarise(Avg.bowling.rank = mean(Pos)) %>%
  arrange(Avg.bowling.rank)

no_of_players_bowling <- no_of_players_bowling %>% filter(Team %in% world_cup_teams)
average_rating_bowling <- average_rating_bowling %>% filter(Team %in% world_cup_teams)

# result : AFG has better avg_ranking and ENG has more no of players in top 50 rankings
# in bowling department AUS has an upper hand in ODI WORLD CUP



# odi all rounder ranking 
html<-read_html("https://www.icc-cricket.com/rankings/mens/player-rankings/odi/all-rounder")
table<-html%>%html_table()
odi_allrounder<-table[[1]]
odi_allrounder<-odi_allrounder%>%select("Pos","Player","Team","Rating","Career Best Rating")
odi_allrounder[1] <- 1:20

# how many players of each country
by_country <- odi_allrounder %>% group_by(Team)
no_of_players_allrounder<-by_country %>% summarise(Top.allrounders = n() ) %>% arrange(desc(Top.allrounders))

# average ratings of players of a team
average_rating_allrounder<-by_country %>% 
  summarise(Avg.allrounders.rank = mean(Pos)) %>% 
  arrange(Avg.allrounders.rank)

no_of_players_allrounder <- no_of_players_allrounder %>% filter(Team %in% world_cup_teams)
average_rating_allrounder <- average_rating_allrounder %>% filter(Team %in% world_cup_teams)

# result : AFG has better avg_ranking and AFG ,BAN, ENG, SL has more no of players in top 20 rankings
# in Allrounder department AFG has an upper hand in ODI WORLD CUP



# team stats 
# previous world cup winner 
html <- read_html("https://www.careerpower.in/cricket-world-cup-winners-list.html")
table<-html %>% html_table()
worldcup_winners <- table[[2]]
colnames(worldcup_winners) <- c(worldcup_winners[1,])
worldcup_winners <- worldcup_winners[2:8,]
worldcup_winners <- worldcup_winners %>% 
  mutate(Team2 = case_when(Team == "India" ~ 'IND', Team == "Pakistan" ~ 'PAK', Team == "Australia" ~ 'AUS', Team == "South Africa" ~ 'SA', Team == "England" ~ 'ENG', Team == "New Zealand" ~ 'NZ', Team == "Sri Lanka" ~ 'SL', Team == "Bangladesh" ~ 'BAN', Team == "Afghanistan" ~ 'AFG', Team == "Netherlands" ~ 'NED')) %>% 
  filter(Team2 %in% world_cup_teams)
worldcup_winners$Team <- worldcup_winners$Team2
worldcup_winners <- worldcup_winners[-c(2,5,6,7)] %>% arrange(desc(Winners))
# AUS is the only country to win 5 odi world cups ,it has better records at ODI WORLD CUP


#team ratings 
html<-read_html("https://www.icc-cricket.com/rankings/mens/team-rankings/odi")
table<-html %>% html_table()
odi_team <- table[[1]]
colnames(odi_team)<-c("Pos","Team","Matches","Points","Ratings")
odi_team$Team <- sapply(strsplit( odi_team$Team, "\n"), "[[", 1)
odi_team <- odi_team[-c(3,4)] %>% 
  mutate(Team2 = case_when(Team == "India" ~ 'IND', Team == "Pakistan" ~ 'PAK', Team == "Australia" ~ 'AUS', Team == "South Africa" ~ 'SA', Team == "England" ~ 'ENG', Team == "New Zealand" ~ 'NZ', Team == "Sri Lanka" ~ 'SL', Team == "Bangladesh" ~ 'BAN', Team == "Afghanistan" ~ 'AFG', Team == "Netherlands" ~ 'NED')) %>% 
  filter(Team2 %in% world_cup_teams)
odi_team$Team <- odi_team$Team2
team_rankings <- odi_team[-4]
# IND is the no 1 odi team in ranking followed by Pakistan,Australia...


data1 <- full_join(no_of_players_batting, average_rating_batting, by="Team") %>% 
  full_join(., no_of_players_bowling) %>% 
  full_join(., average_rating_bowling) %>% 
  full_join(., no_of_players_allrounder) %>% 
  full_join(., average_rating_allrounder) %>% 
  full_join(., worldcup_winners) %>% 
  full_join(., team_rankings) %>% 
  arrange(Team)

data1$Winners = as.numeric(data1$Winners)
data1$Runners = as.numeric(data1$Runners)
data1[is.na(data1)] = 0

write_csv(data1, "team_rankings.csv")
