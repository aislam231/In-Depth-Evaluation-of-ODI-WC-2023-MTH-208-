library(rvest)
library(dplyr)
library(tidyverse)
library(purrr)

# Returns the batting stats of a player
bat_stats <- function(bat_link){
  
  html <- read_html(bat_link)
  table <- html %>% html_table()
  table <- table[[4]]
  
  for (i in 1:length(table$Grouping)){
    if (table$Grouping[i] == ""){
      index <- i
      break
    }
  }
  table <- table[1:index-1,]
  if ("Span" %in% colnames(table)){
    table <- table[-c(2,16)]
  } else{
    table <- table[-15]
  }
  
  world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
  table <- table %>% mutate(Vs = case_when(Grouping == "v India" ~ 'IND', Grouping == "v Pakistan" ~ 'PAK', Grouping == "v Australia" ~ 'AUS', Grouping == "v South Africa" ~ 'SA', Grouping == "v England" ~ 'ENG', Grouping == "v New Zealand" ~ 'NZ', Grouping == "v Sri Lanka" ~ 'SL', Grouping == "v Bangladesh" ~ 'BAN', Grouping == "v Afghanistan" ~ 'AFG', Grouping == "v Netherlands" ~ 'NED')) %>% 
    filter(Vs %in% world_cup_teams)
  table$Grouping <- table$Vs
  table <- table[-15]
  
  colnames(table) <- c("Vs", "Mat", "Bat_Inns", "Bat_NO", "Bat_Runs", "Bat_HS", "Bat_Ave", "Bat_BF", "Bat_SR", "Bat_Centuries", "Bat_Half_centuries", "Bat_Ducks", "Bat_Fours", "Bat_Sixes")
  
  table <- table %>% mutate_at(2:5, as.numeric)
  table <- table %>% mutate_at(7:14, as.numeric)
  
  
  table <- table %>% mutate(Outs = Bat_Inns - Bat_NO)
  
  table$Bat_HS <- sub('\\*.*', "", table$Bat_HS)
  table$Bat_HS = as.numeric(table$Bat_HS)
  
  table[is.na(table)] = 0
  
  table <- table %>% add_row(Vs = "Everyone", Mat = sum(table$Mat), Bat_Inns = sum(table$Bat_Inns), 
                             Bat_NO = sum(table$Bat_NO), Bat_Runs = sum(table$Bat_Runs), Bat_HS = max(table$Bat_HS), 
                             Bat_Ave = sum(table$Bat_Runs)/sum(table$Outs), Bat_BF = sum(table$Bat_BF), 
                             Bat_SR = sum(table$Bat_Runs)/sum(table$Bat_BF)*100, Bat_Centuries = sum(table$Bat_Centuries), 
                             Bat_Half_centuries = sum(table$Bat_Half_centuries), Bat_Ducks = sum(table$Bat_Ducks), 
                             Bat_Fours = sum(table$Bat_Fours), Bat_Sixes = sum(table$Bat_Sixes))
  
  table <- table %>% filter(Vs == "Everyone")
  bat_table <- table[-c(1, 14, 15)]
  bat_table[is.na(bat_table)] = 0
  
  return(bat_table)
}

# Returns the bowling stats of a player
bowl_stats <- function(bowl_link){
  
  html <- read_html(bowl_link)
  table <- html %>% html_table()
  table <- table[[4]]
  
  for (i in 1:length(table$Grouping)){
    if (table$Grouping[i] == ""){
      index <- i
      break
    }
  }
  table <- table[1:index-1,]
  if ("Span" %in% colnames(table)){
    table <- table[-c(2,15)]
  } else{
    table <- table[-14]
  }
  
  world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
  table <- table %>% mutate(Vs = case_when(Grouping == "v India" ~ 'IND', Grouping == "v Pakistan" ~ 'PAK', Grouping == "v Australia" ~ 'AUS', Grouping == "v South Africa" ~ 'SA', Grouping == "v England" ~ 'ENG', Grouping == "v New Zealand" ~ 'NZ', Grouping == "v Sri Lanka" ~ 'SL', Grouping == "v Bangladesh" ~ 'BAN', Grouping == "v Afghanistan" ~ 'AFG', Grouping == "v Netherlands" ~ 'NED')) %>% 
    filter(Vs %in% world_cup_teams)
  table$Grouping <- table$Vs
  table <- table[-c(2,8,14)]
  colnames(table) <- c("Vs", "Bowl_Inns", "Bowl_Overs", "Bowl_Mdns", "Bowl_Runs", "Bowl_Wkts", "Bowl_Ave", "Bowl_Eco", "Bowl_SR", "Bowl_4fer", "Bowl_5fer")
  
  table$Bowl_Overs <- sub('\\..*', "", table$Bowl_Overs)
  table <- table %>% mutate_at(2:11, as.numeric)
  
  table[is.na(table)] = 0
  
  table <- table %>% add_row(Vs = "Everyone", Bowl_Inns = sum(table$Bowl_Inns), 
                             Bowl_Overs = sum(table$Bowl_Overs), Bowl_Mdns = sum(table$Bowl_Mdns), 
                             Bowl_Runs = sum(table$Bowl_Runs), Bowl_Wkts = sum(table$Bowl_Wkts), 
                             Bowl_Ave = sum(table$Bowl_Runs)/sum(table$Bowl_Wkts), Bowl_Eco = sum(table$Bowl_Runs)/sum(table$Bowl_Overs),
                             Bowl_SR = sum(table$Bowl_Overs)/sum(table$Bowl_Wkts)*6, Bowl_4fer = sum(table$Bowl_4fer), 
                             Bowl_5fer = sum(table$Bowl_5fer))
  
  table <- table %>% filter(Vs == "Everyone")
  bowl_table <- table[-1]
  bowl_table[is.na(bowl_table)] = 0
  
  
  return(bowl_table)
}

# Returns the ESPN codes for all players in a team 
player_codes <- function(link){
  html <- read_html(link)
  links <- html %>%  html_elements(".ds-relative.ds-flex.ds-flex-row.ds-space-x-4.ds-p-3") %>%
    html_elements("a") %>% 
    html_attr("href")
  foo <- strsplit(links, "-")
  
  team_players = c()
  odd <- 1:(length(links)/2)
  
  for (i in odd){
    team_players[i] <- foo[[2*i]][length(foo[[2*i]])]
  }
  
  return (team_players)
}

# Returns the names of all players in a team
player_names <- function(link){
  html <- read_html(link)
  links <- html %>%  html_elements(".ds-relative.ds-flex.ds-flex-row.ds-space-x-4.ds-p-3") %>%
    html_elements("a") %>% 
    html_attr("href")
  foo <- strsplit(links, "-")
  
  first_names = c()
  last_names = c()
  odd <- 1:(length(links)/2)
  
  
  for (i in odd){
    first_names[i] <- sub("/cricketers/", "", foo[[2*i]][1])
    lnames = ""
    for (j in 2:(length(foo[[2*i]])-1)){
      lname = foo[[2*i]][j]
      lnames = paste(lnames, lname, sep=" ")
    }
    last_names[i] <- lnames
  }
  
  
  names = c()
  for (i in 1:(length(links)/2)){
    names = str_to_title(paste(first_names, last_names, sep=""))
  }
  
  return (names)
}

# Afghanistan stats
afg_stats <- function(){
  #Afghanistan
  afg_bat_table = tibble()
  afg_bowl_table = tibble()
  
  afg_link <-  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/afghanistan-squad-1398042/series-squads"
  afg_players <- player_codes(afg_link)
  
  afg_bat_links = c()
  for (i in 1:length(afg_players)){
    afg_bat_link = paste("https://stats.espncricinfo.com/ci/engine/player/", afg_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=batting", sep="")
    afg_bat_links[i] = afg_bat_link
  }
  
  afg_bowl_links = c()
  for (i in 1:length(afg_players)){
    afg_bowl_link = paste("https://stats.espncricinfo.com/ci/engine/player/", afg_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=bowling", sep="")
    afg_bowl_links[i] = afg_bowl_link
  }
  
  for (i in 1:13){
    bat_table <- bat_stats(afg_bat_links[i])
    afg_bat_table <- bind_rows(afg_bat_table, bat_table)
  }
  print("AFG Bat done")
  
  for (i in 1:13){
    bowl_table <- bowl_stats(afg_bowl_links[i])
    afg_bowl_table <- bind_rows(afg_bowl_table, bowl_table)
  }
  print("AFG Bowl done")
  
  afg_bat_table[14,] <- NA
  afg_bowl_table[14,] <- NA
  
  bat_table <- bat_stats(afg_bat_links[15])
  afg_bat_table <- bind_rows(afg_bat_table, bat_table)
  bowl_table <- bowl_stats(afg_bowl_links[15])
  afg_bowl_table <- bind_rows(afg_bowl_table, bowl_table)
  
  afg_table <- tibble(afg_bat_table, afg_bowl_table)
  
  names <- as.tibble(player_names(afg_link))
  team <- as.tibble(rep("AFG", length(afg_players)))
  
  colnames(names) = "Player_name"
  colnames(team) = "Team"
  afg_table <- bind_cols(team, names, afg_table)
  
  afg_table[is.na(afg_table)] = 0
  
  return(afg_table)
}

# Netherlands stats
ned_stats <- function(){
  ned_bat_table = tibble()
  ned_bowl_table = tibble()
  
  
  ned_link <- "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/netherlands-squad-1396753/series-squads" 
  ned_players <- player_codes(ned_link)
  
  ned_bat_links = c()
  for (i in 1:length(ned_players)){
    ned_bat_link = paste("https://stats.espncricinfo.com/ci/engine/player/", ned_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=batting", sep="")
    ned_bat_links[i] = ned_bat_link
  }
  
  ned_bowl_links = c()
  for (i in 1:length(ned_players)){
    ned_bowl_link = paste("https://stats.espncricinfo.com/ci/engine/player/", ned_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=bowling", sep="")
    ned_bowl_links[i] = ned_bowl_link
  }
  
  
  for (i in 1:6){
    bat_table <- bat_stats(ned_bat_links[i])
    ned_bat_table <- bind_rows(ned_bat_table, bat_table)
  }
  ned_bat_table[7,] <- NA
  for (i in 8:length(ned_players)){
    bat_table <- bat_stats(ned_bat_links[i])
    ned_bat_table <- bind_rows(ned_bat_table, bat_table)
  }
  print("NED Bat done")
  
  for (i in 1:6){
    bowl_table <- bowl_stats(ned_bowl_links[i])
    ned_bowl_table <- bind_rows(ned_bowl_table, bowl_table)
  }
  ned_bowl_table[7,] <- NA
  for (i in 8:length(ned_players)){
    bowl_table <- bowl_stats(ned_bowl_links[i])
    ned_bowl_table <- bind_rows(ned_bowl_table, bowl_table)
  }
  print("NED Bowl done")
  
  
  ned_table <- tibble(ned_bat_table, ned_bowl_table)
  
  names <- as.tibble(player_names(ned_link))
  team <- as.tibble(rep("NED", length(ned_players)))
  
  colnames(names) = "Player_name"
  colnames(team) = "Team"
  ned_table <- bind_cols(team, names, ned_table)
  
  ned_table[is.na(ned_table)] = 0
  
  return(ned_table)
}

# South Africa stats
sa_stats <- function(){
  sa_bat_table = tibble()
  sa_bowl_table = tibble()
  
  sa_link <-  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/south-africa-squad-1396372/series-squads"
  sa_players <- player_codes(sa_link)
  
  sa_bat_links = c()
  for (i in 1:length(sa_players)){
    sa_bat_link = paste("https://stats.espncricinfo.com/ci/engine/player/", sa_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=batting", sep="")
    sa_bat_links[i] = sa_bat_link
  }
  
  sa_bowl_links = c()
  for (i in 1:length(sa_players)){
    sa_bowl_link = paste("https://stats.espncricinfo.com/ci/engine/player/", sa_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=bowling", sep="")
    sa_bowl_links[i] = sa_bowl_link
  }
  
  
  for (i in 1:14){
    bat_table <- bat_stats(sa_bat_links[i])
    sa_bat_table <- bind_rows(sa_bat_table, bat_table)
  }
  sa_bat_table[15,] <- NA
  for (i in 16:length(sa_players)){
    bat_table <- bat_stats(sa_bat_links[i])
    sa_bat_table <- bind_rows(sa_bat_table, bat_table)
  }
  print("SA Bat done")
  
  for (i in 1:14){
    bowl_table <- bowl_stats(sa_bowl_links[i])
    sa_bowl_table <- bind_rows(sa_bowl_table, bowl_table)
  }
  sa_bowl_table[15,] <- NA
  for (i in 16:length(sa_players)){
    bowl_table <- bowl_stats(sa_bowl_links[i])
    sa_bowl_table <- bind_rows(sa_bowl_table, bowl_table)
  }
  print("SA Bowl done")
  
  
  sa_table <- tibble(sa_bat_table, sa_bowl_table)
  
  names <- as.tibble(player_names(sa_link))
  team <- as.tibble(rep("SA", length(sa_players)))
  
  colnames(names) = "Player_name"
  colnames(team) = "Team"
  sa_table <- bind_cols(team, names, sa_table)
  
  sa_table[is.na(sa_table)] = 0
  
  return(sa_table)
}

# Past two years data of all the players of all teams
stats_2 <- function(n){
  team_links <- c("https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/afghanistan-squad-1398042/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/australia-squad-1396545/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/bangladesh-squad-1400121/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/england-squad-1396558/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/india-squad-1396344/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/netherlands-squad-1396753/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/new-zealand-squad-1397557/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/pakistan-squad-1399493/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/south-africa-squad-1396372/series-squads",
                  "https://www.espncricinfo.com/series/icc-cricket-world-cup-2023-24-1367856/sri-lanka-squad-1400061/series-squads")
  
  world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
  
  team_link <- team_links[n]
  team_name <- world_cup_teams[n]
  
  if (n == 1){
    afg_stats()
  }
  else if (n == 6){
    ned_stats()
  }
  else if (n == 9){
    sa_stats()
  }
  else{
    team_bat_table = tibble()
    team_bowl_table = tibble()
    
    team_players = player_codes(team_link)
    
    team_bat_links = c()
    for (i in 1:length(team_players)){
      team_bat_link = paste("https://stats.espncricinfo.com/ci/engine/player/", team_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=batting", sep="")
      team_bat_links[i] = team_bat_link
    }
    
    
    team_bowl_links = c()
    for (i in 1:length(team_players)){
      team_bowl_link = paste("https://stats.espncricinfo.com/ci/engine/player/", team_players[i], ".html?class=2;spanmax1=04+Oct+2023;spanmin1=04+Oct+2021;spanval1=span;template=results;type=bowling", sep="")
      team_bowl_links[i] = team_bowl_link
    }
    
    for (i in 1:length(team_bat_links)){
      bat_table <- bat_stats(team_bat_links[i])
      team_bat_table <- bind_rows(team_bat_table, bat_table)
    }
    print(paste(world_cup_teams[n], "Bat done"))
    
    for (i in 1:length(team_bowl_links)){
      bowl_table <- bowl_stats(team_bowl_links[i])
      team_bowl_table <- bind_rows(team_bowl_table, bowl_table)
    }
    print(paste(world_cup_teams[n], "Bowl done"))
    
    t <- strsplit(team_link, "\\/")[[1]][6]
    team <- sub("-squad.*" ,"", t)
    
    team_table <- tibble(team_bat_table, team_bowl_table)
    
    names <- as.tibble(player_names(team_link))
    team_names <- as.tibble(rep(team_name, length(team_players)))
    
    colnames(names) = "Player_name"
    colnames(team_names) = "Team"
    team_table <- bind_cols(team_names, names, team_table)
    
    return(team_table)
  }
}

# Data frame for last 2 years data for all the players
data_2 <- tibble()
for (i in 1:10){
  team_table <- stats_2(i)
  data_2 <- bind_rows(data_2, team_table)
}