# Libraries ----
  library(shiny)
  library(shinythemes)
  library(shinydashboard)
  library(lubridate)
  library(ggplot2)
  library(dplyr)
  library(plotly)
  library(viridis)
  library(fmsb)
  
# Data and functions ----
  load("./Data/data_2.Rdata")
  load("./Data/team_stats.Rdata")
  load("./Data/schedule.Rdata")
  load("./Data/points_table.Rdata")
  load("./Data/win_record.Rdata")
  
  world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
  mcolor <- c("#025F9A", "#DBC669", "#14413B", "#194591", "#0188E0", "#FC5625", "#1E1D23", "#1A4335", "#297553", "#1E3064")
  lcolor <- c("#ED3A4C", "#2A3D3D", "#AC3924", "#991C39", "#F49341", "#024989", "#A4A3B5", "#52886B", "#E2C624", "#EAE244")
  custom_colors <- c(IND="#0188E0",PAK="#1A4335",AUS="#DBC669",SA="#297553",BAN="#14413B",
                     NZ="#1E1D23",SL="#1E3064",NED="#FC5625",AFG="#025F9A",ENG="#194591")
  
  # Function to create a bat ball spider chart for a team
  batball_radar <- function(n){
    max_stats <- c()
    min_stats <- c()
    team_stats <- team_stats %>% mutate(Team_Bowl_RAve = 1/Team_Bowl_Ave, Team_Bowl_REco = 1/Team_Bowl_Eco, Team_Bowl_RSR = 1/Team_Bowl_SR)
    
    for (i in 2:15){
      max_stats[i-1] <- max(team_stats[i])
      min_stats[i-1] <- min(team_stats[i])
    }
    team_stats[11,1] = "Max"
    team_stats[12,1] = "Min"
    
    for (i in 2:15){
      team_stats[11,i] = max_stats[i-1]
      team_stats[12,i] = min_stats[i-1]
    }
    
    rownames(team_stats) <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL", "Max", "Min")
    batball_stats <- team_stats[-c(1, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
    win_stats <- team_stats[-c(1,2,3,4,5,6,10,11,13,14,15)]
    colnames(win_stats)[4] <- "Win_perc"
    batball_stats <- batball_stats %>% relocate(Team_Bowl_REco, Team_Bowl_RAve, Team_Bat_Ave, Team_Bat_SR, Team_Bowl_RSR)
    colnames(batball_stats) <- c("Bowl R Economy", "Bowl R Average", "Bat Average", "Bat Strike Rate", "Bowl R Strike Rate")
    win_stats <- win_stats %>% relocate(Win_perc)
    colnames(win_stats) <- c("Top All-Rounders", "Top Batters", "Win percentage", "Top Bowlers")
    
    batball_data <- batball_stats[c("Max", "Min", world_cup_teams[n]), ]
    win_data <- win_stats[c("Max", "Min", world_cup_teams[n]), ]
    
    title <- paste(world_cup_teams[n], "Data")
    
    return(radarchart(batball_data, title = title, pcol = lcolor[n], pfcol = scales::alpha(mcolor[n], 0.5)))
    
  }
  
  # Function to create a top players spider chart for a team
  win_radar <- function(n){
    max_stats <- c()
    min_stats <- c()
    team_stats <- team_stats %>% mutate(Team_Bowl_RAve = 1/Team_Bowl_Ave, Team_Bowl_REco = 1/Team_Bowl_Eco, Team_Bowl_RSR = 1/Team_Bowl_SR)
    
    for (i in 2:15){
      max_stats[i-1] <- max(team_stats[i])
      min_stats[i-1] <- min(team_stats[i])
    }
    team_stats[11,1] = "Max"
    team_stats[12,1] = "Min"
    
    for (i in 2:15){
      team_stats[11,i] = max_stats[i-1]
      team_stats[12,i] = min_stats[i-1]
    }
    
    rownames(team_stats) <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL", "Max", "Min")
    batball_stats <- team_stats[-c(1, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
    win_stats <- team_stats[-c(1,2,3,4,5,6,10,11,13,14,15)]
    colnames(win_stats)[4] <- "Win_perc"
    batball_stats <- batball_stats %>% relocate(Team_Bowl_REco, Team_Bowl_RAve, Team_Bat_Ave, Team_Bat_SR, Team_Bowl_RSR)
    colnames(batball_stats) <- c("Bowl R Economy", "Bowl R Average", "Bat Average", "Bat Strike Rate", "Bowl R Strike Rate")
    win_stats <- win_stats %>% relocate(Top.alrndrs, Top.batters, Win_perc, Top.alrndrs)
    colnames(win_stats) <- c("Top All-Rounders", "Top Batters", "Win percentage", "Top Bowlers")
    
    batball_data <- batball_stats[c("Max", "Min", world_cup_teams[n]), ]
    win_data <- win_stats[c("Max", "Min", world_cup_teams[n]), ]
    
    title <- paste(world_cup_teams[n], "Data")
    
    return(radarchart(win_data, title = title, pcol = lcolor[n], pfcol = scales::alpha(mcolor[n], 0.5)))
    
  }
  
  # Function to create bat ball comparison spider charts for two teams
  batball_comp <- function(m, n){
    max_stats <- c()
    min_stats <- c()
    team_stats <- team_stats %>% mutate(Team_Bowl_RAve = 1/Team_Bowl_Ave, Team_Bowl_REco = 1/Team_Bowl_Eco, Team_Bowl_RSR = 1/Team_Bowl_SR)
    
    for (i in 2:15){
      max_stats[i-1] <- max(team_stats[i])
      min_stats[i-1] <- min(team_stats[i])
    }
    team_stats[11,1] = "Max"
    team_stats[12,1] = "Min"
    
    for (i in 2:15){
      team_stats[11,i] = max_stats[i-1]
      team_stats[12,i] = min_stats[i-1]
    }
    
    rownames(team_stats) <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL", "Max", "Min")
    batball_stats <- team_stats[-c(1, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
    win_stats <- team_stats[-c(1,2,3,4,5,6,10,11,13,14,15)]
    colnames(win_stats)[4] <- "Win_perc"
    batball_stats <- batball_stats %>% relocate(Team_Bowl_REco, Team_Bowl_RAve, Team_Bat_Ave, Team_Bat_SR, Team_Bowl_RSR)
    colnames(batball_stats) <- c("Bowl R Economy", "Bowl R Average", "Bat Average", "Bat Strike Rate", "Bowl R Strike Rate")
    win_stats <- win_stats %>% relocate(Win_perc)
    colnames(win_stats) <- c("Top All-Rounders", "Top Batters", "Win percentage", "Top Bowlers")
    
    batball_data <- batball_stats[c("Max", "Min", world_cup_teams[m], world_cup_teams[n]), ]
    win_data <- win_stats[c("Max", "Min", world_cup_teams[m], world_cup_teams[n]), ]
    
    title <- paste(world_cup_teams[m],"and", world_cup_teams[n], "Data Comparison")
    mcol <- c(mcolor[m], mcolor[n])
    lcol <- c(lcolor[m], lcolor[n])
    radarchart(batball_data, title = title, pcol = lcol, pfcol = scales::alpha(mcol, 0.5))
    
    legend("topright", legend = c(world_cup_teams[m], world_cup_teams[n]), fill = c(mcolor[m], mcolor[n]))
  }
  
  # Function to create top players comparison spider charts for two teams
  win_comp <- function(m, n){
    max_stats <- c()
    min_stats <- c()
    team_stats <- team_stats %>% mutate(Team_Bowl_RAve = 1/Team_Bowl_Ave, Team_Bowl_REco = 1/Team_Bowl_Eco, Team_Bowl_RSR = 1/Team_Bowl_SR)
    
    for (i in 2:15){
      max_stats[i-1] <- max(team_stats[i])
      min_stats[i-1] <- min(team_stats[i])
    }
    team_stats[11,1] = "Max"
    team_stats[12,1] = "Min"
    
    for (i in 2:15){
      team_stats[11,i] = max_stats[i-1]
      team_stats[12,i] = min_stats[i-1]
    }
    
    rownames(team_stats) <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL", "Max", "Min")
    batball_stats <- team_stats[-c(1, 4, 5, 6, 7, 8, 9, 10, 11, 12)]
    win_stats <- team_stats[-c(1,2,3,4,5,6,10,11,13,14,15)]
    colnames(win_stats)[4] <- "Win_perc"
    batball_stats <- batball_stats %>% relocate(Team_Bowl_REco, Team_Bowl_RAve, Team_Bat_Ave, Team_Bat_SR, Team_Bowl_RSR)
    colnames(batball_stats) <- c("Bowl R Economy", "Bowl R Average", "Bat Average", "Bat Strike Rate", "Bowl R Strike Rate")
    win_stats <- win_stats %>% relocate(Top.alrndrs, Top.batters, Win_perc, Top.alrndrs)  
    colnames(win_stats) <- c("Top All-Rounders", "Top Batters", "Win percentage", "Top Bowlers")
    
    batball_data <- batball_stats[c("Max", "Min", world_cup_teams[m], world_cup_teams[n]), ]
    win_data <- win_stats[c("Max", "Min", world_cup_teams[m], world_cup_teams[n]), ]
    
    title <- paste(world_cup_teams[m],"and", world_cup_teams[n], "Data Comparison")
    mcol <- c(mcolor[m], mcolor[n])
    lcol <- c(lcolor[m], lcolor[n])
    radarchart(win_data, title = title, pcol = lcol, pfcol = scales::alpha(mcol, 0.5))
    
    legend("topright", legend = c(world_cup_teams[m], world_cup_teams[n]), fill = c(mcolor[m], mcolor[n]))
  }
  
  # Function to create the points table after a certain number of matches had been played
  pts_mat_func <- function(mat){
    blank_table <- points_table
    blank_table[c(2,3,4,6)] <- rep(0,10)
    
    pts_mat <- blank_table
    if(mat == 0){
      blank_table <- blank_table %>% mutate_at(c(2,3,4,6), as.integer)
      return(blank_table)
    }
    for (i in 1:mat){
      team1 <- schedule[i, 1]
      team2 <- schedule[i, 2]
      
      index1 <- which(pts_mat$Team==team1)
      index2 <- which(pts_mat$Team==team2)
      
      pts_mat[index1, 2] <- pts_mat[index1, 2] + 1
      pts_mat[index2, 2] <- pts_mat[index2, 2] + 1
      pts_mat[index1, 6] <- pts_mat[index1, 6] + 2
      pts_mat[index1, 3] <- pts_mat[index1, 3] + 1
      pts_mat[index2, 4] <-pts_mat[index2, 4] + 1
      
      pts_mat <- pts_mat %>% arrange(desc(Pts), desc(NRR))
    }
    pts_mat <- pts_mat %>% mutate_at(c(2,3,4,6), as.integer)
    return(pts_mat)
  }
  
  # Function to calculate the qualification probability of each team after 
  # a certain number of matches had been played if the assigned probability is equal
  eq_prob <- function(mat){
    blank_table <- points_table
    blank_table[c(2,3,4,6)] <- rep(0,10)
    
    pts_end <- pts_mat_func(mat)
    
    qteams <- function(){
      for (n in (mat+1):45){
        team1 <- schedule[n, 1]
        team2 <- schedule[n, 2]
        index1<-which(pts_end$Team==team1)
        index2<-which(pts_end$Team==team2)
        w <- rbinom(n=1,size=1,prob = 0.5)
        pts_end[index1, 2] <- pts_end[index1, 2] + 1
        pts_end[index2, 2] <- pts_end[index2, 2] + 1
        if(w == 1){
          pts_end[index1, 6] <- pts_end[index1, 6] + 2
          pts_end[index1, 3] <- pts_end[index1, 3] + 1
          pts_end[index2, 4] <-pts_end[index2, 4] + 1
        } else{
          pts_end[index2, 6] <- pts_end[index2, 6] + 2
          pts_end[index2, 3] <- pts_end[index2, 3] + 1
          pts_end[index1, 4] <-pts_end[index1, 4] + 1
        }
        if (mat >= 25){
          pts_end <- pts_end %>% arrange(desc(Pts), desc(NRR))
        }
        else{
          pts_end <- pts_end %>% arrange(desc(Pts), Rank)
        }
      }
      teams <- pts_end$Team[1:4]
      return(teams)
    }
    
    world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
    qprob <- data.frame(world_cup_teams, rep(0, 10))
    colnames(qprob) <- c("Team", "Mat_won")
    
    for (i in 1:1e3){
      c <- qteams()
      for (j in 1:10){
        qprob[j,2] <- qprob[j,2] + as.numeric(qprob[j,1] %in% c)
      }
    }
    qprob <- qprob %>% mutate(Qualification_probability = `Mat_won`/10)
    qprob <- qprob[-2]
    qprob <- qprob %>% arrange(desc(Qualification_probability))
    return(qprob)
  }
  
  # Function to calculate the qualification probability of each team after 
  # a certain number of matches had been played if the assigned probability is based on past records
  past_prob <- function(mat){
    blank_table <- points_table
    blank_table[c(2,3,4,6)] <- rep(0,10)
    
    pts_end <- pts_mat_func(mat)
    
    qteams <- function(){
      for (n in (mat+1):45){
        team1 <- schedule[n, 1]
        team2 <- schedule[n, 2]
        index1<-which(pts_end$Team==team1)
        index2<-which(pts_end$Team==team2)
        id1 <- which(win_record$Team==team1)
        id2 <- which(win_record$Team==team2) + 1
        w <- rbinom(n=1,size=1,prob = win_record[id1, id2])
        pts_end[index1, 2] <- pts_end[index1, 2] + 1
        pts_end[index2, 2] <- pts_end[index2, 2] + 1
        if(w == 1){
          pts_end[index1, 6] <- pts_end[index1, 6] + 2
          pts_end[index1, 3] <- pts_end[index1, 3] + 1
          pts_end[index2, 4] <-pts_end[index2, 4] + 1
        } else{
          pts_end[index2, 6] <- pts_end[index2, 6] + 2
          pts_end[index2, 3] <- pts_end[index2, 3] + 1
          pts_end[index1, 4] <-pts_end[index1, 4] + 1
        }
        if (mat >= 25){
          pts_end <- pts_end %>% arrange(desc(Pts), desc(NRR))
        }
        else{
          pts_end <- pts_end %>% arrange(desc(Pts), Rank)
      }
      teams <- pts_end$Team[1:4]
      return(teams)
      }
    }
    
    world_cup_teams <- c("AFG","AUS","BAN","ENG","IND","NED","NZ","PAK","SA","SL")
    qprob <- data.frame(world_cup_teams, rep(0, 10))
    colnames(qprob) <- c("Team", "Mat_won")
    
    for (i in 1:1e3){
      c <- qteams()
      for (j in 1:10){
        qprob[j,2] <- qprob[j,2] + as.numeric(qprob[j,1] %in% c)
      }
    }
    qprob <- qprob %>% mutate(Qualification_probability = `Mat_won`/10)
    qprob <- qprob[-2]
    qprob <- qprob %>% arrange(desc(Qualification_probability))
    return(qprob)
  }
  
  
  
# Define UI for shiny app ----
  ui <- fluidPage(theme = shinytheme('darkly'), 
    tags$head(
      tags$style(HTML('.avgpos { background-color: #317e61; color: #FFFFFF;margin-right: 10px; margin-bottom:10px;border-radius:10px;}')),
      tags$style(HTML('.avgneg { background-color: #ff4136; color: #FFFFFF;margin-right: 10px;border-radius:10px;}')),
      tags$style(HTML('.margin{margin-top: 50px; }')),
      tags$style(HTML('.top{ background-color: #efefef;margin-bottom:40px;border: 10px solid white; border-radius:10px;}')),
      tags$style(HTML('.head{ background-color: #c5d6ff;color: #0f161c;padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px}')),
      tags$style(HTML('.back{background-color: #c5d6ff}'))),
    
    
  # App title ----
    titlePanel("Cricket World Cup 2023"),
    
    navbarPage("In-Depth Analysis",
               
        tabsetPanel(
          
        # Batting Analysis ----  
            tabPanel("Batting Analysis", 
                       sidebarPanel( 
                         sliderInput(inputId = "runs",
                                     label = "Runs more than:",
                                     min = 200,
                                     max = 1000,
                                     value = 400)),
                                                                     
                        mainPanel(
                          tabsetPanel(
                            tabPanel("Most Runs", plotOutput("ggplot1")),
                            tabPanel("Highest Strike Rate", plotOutput("ggplot2")),
                            tabPanel("Avg vs SR", plotlyOutput("ggplot3"))
                       )
                        )
                         ),
        # Bowling Analysis ----
            tabPanel("Bowling Analysis",
                     sidebarPanel(
                       sliderInput(inputId = "wickets",
                                   label = "Wickets more than:",
                                   min = 0,
                                   max = 35,
                                   value = 20),
                       sliderInput(inputId = "overs",
                                   label = "Overs more than:",
                                   min = 40,
                                   max = 100,
                                   value = 50)),
                     
                     mainPanel(tabsetPanel(
                       tabPanel("Most Wickets", plotOutput("ggplot4")),
                       tabPanel("Best Economy", plotOutput("ggplot5")),
                       tabPanel("Avg vs Eco", plotlyOutput("ggplot6"))
                     )
                      )
                       ),
        # Team Wise Analysis ----
            tabPanel("Team Wise Analysis",
                     sidebarPanel(
                       selectInput(inputId = "team",
                                   label = "Choose a team for analysis:",
                                   choices = c("Afghanistan", "Australia", "Bangladesh", "England", "India", 
                                               "Netherlands", "New Zealand", "Pakistan", "South Africa", "Sri Lanka"),
                                   selected = "India"
                                   )          
                                  ),
                   
          
                     mainPanel(tabsetPanel(
                       tabPanel("Team Table", tableOutput("table")),
                       tabPanel("Batters Comparison", plotOutput("ggplot7")),
                       tabPanel("Bowlers Comparison", plotOutput("ggplot8")),
                       tabPanel("Bat-Ball Strength", plotOutput("ggplot9")),
                       tabPanel("Top Players", plotOutput("ggplot10"))
                     )
                      ) 
                       ),
        # Comparison between Teams ----
            tabPanel("Comparison between Teams",
                     sidebarPanel(
                       checkboxGroupInput(inputId = "teams",
                                          label = "Choose teams to compare",
                                          choices = c("Afghanistan"=1, "Australia"=2, "Bangladesh"=3, "England"=4, "India"=5,
                                                      "Netherlands"=6, "New Zealand"=7, "Pakistan"=8, "South Africa"=9, "Sri Lanka"=10)
                                          ),
                       sliderInput(inputId = "matches",
                                   label = "Choose No of Matches:",
                                   min = 0,
                                   max = 45,
                                   value = 25
                                   ),
                       selectInput(inputId = "prob",
                                   label = "Assign Probability:",
                                   choices = c("Equal"=1, "Past records"=2),
                                   selected = "Equal"
                                  )          
                                 ),
                

                     mainPanel(tabsetPanel(
                       tabPanel("Bat-Ball Strength", plotOutput("ggplot11")),
                       tabPanel("Top Players", plotOutput("ggplot12")),
                       tabPanel("Points Table", tableOutput("pts_table")),
                       tabPanel("Qualification Probability", tableOutput("qprob"))
                     )
                      )
                       )
        
          )
            )
             )
  
# Define server logic ----
  server <- function(input, output,session) {
    # Reactive ----
      datasetInput <- reactive({
        switch(input$team,
               "Afghanistan" = subset(data_2, Team == "AFG")[-c(1,4,5)],
               "Australia" = subset(data_2, Team == "AUS")[-c(1,4,5)],
               "Bangladesh" = subset(data_2, Team == "BAN")[-c(1,4,5)],
               "England" = subset(data_2, Team == "ENG")[-c(1,4,5)],
               "India" = subset(data_2, Team == "IND")[-c(1,4,5)],
               "Netherlands" = subset(data_2, Team == "NED")[-c(1,4,5)],
               "New Zealand" = subset(data_2, Team == "NZ")[-c(1,4,5)],
               "Pakistan" = subset(data_2, Team == "PAK")[-c(1,4,5)],
               "South Africa" = subset(data_2, Team == "SA")[-c(1,4,5)],
               "Sri Lanka" = subset(data_2, Team == "SL")[-c(1,4,5)])
      })
      
      countryInput <- reactive({
        switch(input$team,
               "Afghanistan" = 1,
               "Australia" = 2,
               "Bangladesh" = 3,
               "England" = 4,
               "India" = 5,
               "Netherlands" = 6,
               "New Zealand" = 7,
               "Pakistan" = 8,
               "South Africa" = 9,
               "Sri Lanka" = 10)
      })
        
      teamsInput <- reactive({
        switch(input$teams,
               "Afghanistan" = 1,
               "Australia" = 2,
               "Bangladesh" = 3,
               "England" = 4,
               "India" = 5,
               "Netherlands" = 6,
               "New Zealand" = 7,
               "Pakistan" = 8,
               "South Africa" = 9,
               "Sri Lanka" = 10)
      })
        
      probInput <- reactive({
        switch(input$prob,
               "Equal" = 1,
               "Past" = 2)
      })
        
        
      selectedCount <- reactiveVal(0)
      
    # Update the selected checkboxes counter whenever checkboxes change ----
      observeEvent(input$checkboxes, {
        selectedCount(length(input$checkboxes))
        
        # If more than two checkboxes are selected, unselect the last one
        if (selectedCount() > 2) {
          last_selected <- tail(input$checkboxes, 1)
          updateCheckboxGroupInput(session, "checkboxes", selected = setdiff(input$checkboxes, last_selected))
          selectedCount(2)
        }
      })    
      
    
    
    # Write caption ----
      output$caption <- renderText({
        input$caption
      })

    
    # Batting plots ----
      
      # Most runs bar graph
      output$ggplot1 <- renderPlot({
        dataset <- data_2 %>% arrange(desc(Bat_Runs))
        dataset2 <- dataset[1:10,]
        ggplot(dataset2) +
          geom_bar(aes(x = reorder(Player_name, -Bat_Runs), y = Bat_Runs, fill = Team), stat="identity") +
          geom_line(aes(x=Player_name, y=Bat_Ave*10,group=2), color="red",stat="identity")+
          scale_y_continuous(sec.axis = sec_axis(~./10,name="Batting Average"))+
          geom_point(aes(x = Player_name, y = Bat_Ave*10), color = "black")+
          geom_text(aes(label=round(Bat_Ave, 2), x=Player_name, y=Bat_Ave*10), colour="white",vjust = -0.5, nudge_y = 0.2, size = 3)+
          geom_text(aes(label= Bat_Runs, x=Player_name, y=Bat_Runs), colour="black",vjust = -0.5, nudge_y = 0.2, size = 3)+
          theme(axis.text.x = element_text(angle = 45, hjust = 1))+
          labs(x = "Player Name", y ="Runs Scored")+
          scale_fill_manual(values = custom_colors)+
          labs(title="Players With Most Runs")
      })
      
      # Highest strike rate bar graph
      output$ggplot2 <- renderPlot({
        dataset <- data_2 %>% filter(Bat_Runs>=input$runs)
        dataset <- dataset %>% arrange(desc(Bat_SR))
        dataset3 <- dataset[1:10,]
        ggplot(dataset3) +
          geom_bar(aes(x = reorder(Player_name, -Bat_SR), y = Bat_SR, fill = Team), stat="identity") +
          geom_line(aes(x=Player_name, y=Bat_Runs/10,group=2), color="red",stat="identity")+
          scale_y_continuous(sec.axis = sec_axis(~./.1,name="Runs Scored"))+
          geom_point(aes(x = Player_name, y = Bat_Runs/10), color = "black")+
          geom_text(aes(label=Bat_Runs, x=Player_name, y=Bat_Runs/10), colour="white",vjust = -0.5, nudge_y = 0.2, size = 3)+
          geom_text(aes(label=round(Bat_SR, 2), x=Player_name, y=Bat_SR), colour="black",vjust = -0.5, nudge_y = 0.2, size = 3)+
          theme(axis.text.x = element_text(angle = 45, hjust = 1))+
          labs(x = "Player Name", y ="Strike Rate")+
          scale_fill_manual(values = custom_colors)+
          labs(title=paste("Players With Highest Strike Rate (min.", input$runs, "runs)"))
        
      })
      
      # Avg vs SR bubble chart
      output$ggplot3 <- renderPlotly({
        dataset <- data_2 %>% filter(Bat_Runs>=input$runs)
        ggplotly(ggplot(dataset, aes(x=Bat_Ave, y=Bat_SR, col=Team,text=Player_name)) +
                   geom_point(aes(size=Bat_Runs),alpha=0.5)+
                   labs(title= paste("Batting Average Vs Batting Strike rate (min.", input$runs, "runs)"))+
                   labs(x = "Batting Average", y ="Batting Strike Rate")+
                   labs(size = "Runs Scored")+
                   scale_color_manual(values = custom_colors), tooltip = "text")
      })
      
      
    # Bowling Plots ----
      
      # Most wickets graph
      output$ggplot4 <- renderPlot({
      datase <- data_2 %>% arrange(desc(Bowl_Wkts))
      dataset4 <- datase[1:10,]
      ggplot(dataset4) +
        geom_bar(aes(x = reorder(Player_name, -Bowl_Wkts), y = Bowl_Wkts, fill = Team), stat="identity") +
        geom_line(aes(x=Player_name, y=Bowl_Ave,group=2), color="red",stat="identity")+
        scale_y_continuous(sec.axis = sec_axis(~./1,name="Bowling Average"))+
        geom_point(aes(x = Player_name, y = Bowl_Ave), color = "black")+
        geom_text(aes(label=round(Bowl_Ave, 2), x=Player_name, y=Bowl_Ave), colour="white",vjust = -0.5, nudge_y = 0.2, size = 3)+
        geom_text(aes(label= Bowl_Wkts, x=Player_name, y=Bowl_Wkts), colour="black",vjust = -0.5, nudge_y = 0.2, size = 3)+
        theme(axis.text.x = element_text(angle = 45, hjust = 1))+
        labs(x = "Player Name", y ="Wickets")+
        scale_fill_manual(values = custom_colors)+
        labs(title="Highest Wicket Takers")
      })
      
      # Best economy bar graph
      output$ggplot5 <- renderPlot({datase <- data_2 %>% filter(Bowl_Overs>=input$overs)
      datase <- datase %>% arrange(Bowl_Eco)
      dataset4 <- datase[1:10,]
      ggplot(dataset4) +
        geom_bar(aes(x = reorder(Player_name, Bowl_Eco), y = Bowl_Eco, fill = Team), stat="identity") +
        geom_line(aes(x=Player_name, y=Bowl_Wkts/7,group=2), color="red",stat="identity")+
        scale_y_continuous(sec.axis = sec_axis(~.*7,name="Wickets"))+
        geom_point(aes(x = Player_name, y = Bowl_Wkts/7), color = "black")+
        geom_text(aes(label=Bowl_Wkts, x=Player_name, y=Bowl_Wkts/7), colour="white",vjust = -0.5, nudge_y = 0.2, size = 3)+
        geom_text(aes(label=round(Bowl_Eco, 2), x=Player_name, y=Bowl_Eco), colour="black",vjust = -0.5, nudge_y = 0.2, size = 3)+
        theme(axis.text.x = element_text(angle = 45, hjust = 1))+
        labs(x = "Player Name", y ="Economy Rate")+
        scale_fill_manual(values = custom_colors)+
        labs(title= paste("Most Economical Bowler (min.", input$overs, "overs)"))
      
      })
      
      # Avg vs Eco bubble chart
      output$ggplot6 <- renderPlotly({
        data4 <- data_2 %>% filter(Bowl_Wkts>=input$wickets)
        gplot3 <- ggplot(data4, aes(x=Bowl_Ave, y=Bowl_Eco, col=Team,text=Player_name)) +
          geom_point(aes(size=Bowl_Wkts),alpha=0.5)+
          labs(title= paste("Bowling Average Vs Bowling Economy (min.", input$wickets, "wickets)"))+
          labs(x = "Bowling Average", y ="Bowling Economy")+
          labs(size = "Wickets taken")
        scale_color_manual(values = custom_colors)
        ggplotly(gplot3, tooltip = "text")
      })
        
      
    # Team plots ----
      
      # Team table
      output$table <- renderTable({
        datasetInput()
      })
      
      # Batters divergence chart
      output$ggplot7 <- renderPlot({
        n <- countryInput()
        custom2 <- c(below="red",above="green")
        data3 <- data_2 %>% filter(Team==world_cup_teams[n]) %>% filter(Type == "Batsman" | Type == "Allrounder")
        weigthed_average <- team_stats[n, 2]
        data3$comp_ave <- ifelse(data3$Bat_Ave-weigthed_average  < 0  , "below", "above") 
        data3 <- data3[order(data3$Bat_Ave-weigthed_average ), ] 
        data3$Player_name <- factor(data3$Player_name, levels = data3$Player_name) 
        ggplot(data3, aes(x=Player_name, y=Bat_Ave-weigthed_average , label=Bat_Ave)) + 
          geom_bar(stat='identity', aes(fill=comp_ave), width=.5)+
          scale_fill_manual(values = custom2)+
          coord_flip()+
          ylab(paste("Batting Average =", round(weigthed_average, 2))) +
          xlab("Players") +
          ggtitle(paste("Comparing batters of", world_cup_teams[n], "with each other"))
      })
        
      # Bowlers divergence chart
      output$ggplot8 <- renderPlot({
        n <- countryInput()
        custom2 <- c(below="red",above="green")
        data4 <- data_2 %>% filter(Team==world_cup_teams[n]) %>% filter(Type == "Bowler" | Type == "Allrounder")
        weigthed_average1 <- team_stats[n, 4]
        data4$comp_ave <- ifelse(weigthed_average1-data4$Bowl_Ave  < 0  , "below", "above") 
        data4 <- data4[order(weigthed_average1 - data4$Bowl_Ave ,decreasing=F), ] 
        data4$Player_name <- factor(data4$Player_name, levels = data4$Player_name) 
        ggplot(data4, aes(x=Player_name, y=weigthed_average1-data4$Bowl_Ave , label=Bowl_Ave)) + 
          geom_bar(stat='identity', aes(fill=comp_ave), width=.5)+
          scale_fill_manual(values = custom2)+
          coord_flip()+
          ylab(paste("Bowling Average =", round(weigthed_average1, 2))) +
          xlab("Players") +
          ggtitle(paste("Comparing bowlers of", world_cup_teams[n], "with each other"))
      })
        
      # Bat ball spider chart
      output$ggplot9 <- renderPlot({
        n <- countryInput()
        batball_radar(n)
      })
      
      # Top players spider chart
      output$ggplot10 <- renderPlot({
        n <- countryInput()
        win_radar(n)
      })
      
      
      
    # Team Comparison Plots ----
      
      # Bat ball spider chart
      output$ggplot11 <- renderPlot({
        
        m <- as.numeric(input$teams)[1]
        n <- as.numeric(input$teams)[2]
        
        batball_comp(m, n)
      })
      
      # Top players spider chart
      output$ggplot12 <- renderPlot({
        
        m <- as.numeric(input$teams)[1]
        n <- as.numeric(input$teams)[2]
        
        win_comp(m, n)
      })
      
      # Points table
      output$pts_table <- renderTable({
        table <- pts_mat_func(input$matches)
        if(input$matches == 25){
          table
        }
        else{
          table[-c(5, 7)]
        }
      })
      
      # Qualification probability
      output$qprob <- renderTable({
          eqprob <- as.numeric(input$prob)
          if (eqprob == 1){
            eq_prob(input$matches)
          }
          else {
            past_prob(input$matches)
          }
      })
    
    
}
# Run the application ----
  shinyApp(ui = ui, server = server)


 